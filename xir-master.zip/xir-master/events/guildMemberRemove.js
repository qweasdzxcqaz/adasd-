module.exports = member => {
  let guild = member.guild;
  member.send('Aramızdan Gittin İçin Çok Üzüldük.');
  guild.defaultChannel.sendMessage(`${member.user.username} Aramızdan Gittin İçin Çok Üzüldük.`);
};