const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

exports.run = (client, message, params) => {
  const embedyardim = new Discord.RichEmbed()
  .setTitle("Komutlar")
  .setDescription('')
  .setColor(0x00ffff)
  .addField("**Eğlence Komutları + kullanıcı komutları (2)**", "+talep talep açarsınız\n +trampet dene ve gör\n +top10 bizi kullanan sunucuların en büyük 10 suncuyu listeler\n+banned dene ve gör\n+havadurumu (il) \n+simit simit yersiniz\n+stresçarkı strer çarkı çevirirsiniz ve bu süre hesplanır\n+sor soru sorar\n+avatarım = Avatarınınızı Gösterir. \n+herkesebendençay = Herkese Çay Alırsınız. \n+koş = Koşarsınız.\n+çayiç = Çay İçersiniz. \n+çekiç = İstediğiniz Kişiye Çekiç Atarsınız. \n+çayaşekerat = Çaya Şeker Atarsınız. \n+yumruh-at = Yumruk Atarsınız. \n+yaz = Bota İstediğiniz Şeyi Yazdırırsınız. \n+sunucuresmi = BOT Sunucunun Resmini Atar. \n+sunucubilgi = BOT Sunucu Hakkında Bilgi Verir. \n+kullanıcıbilgim = Sizin Hakkınızda Bilgi Verir")
  .setFooter('**--------------------------**')
  if (!params[0]) {
    const commandNames = Array.from(client.commands.keys());
    const longest = commandNames.reduce((long, str) => Math.max(long, str.length), 0);
    message.channel.send(embedyardim);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.author.send('asciidoc', `= ${command.help.name} = \n${command.help.description}\nDoğru kullanım: ` + prefix + `${command.help.usage}`);
    }
  }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['eğlence2'],
  permLevel: 0
};

exports.help = {
  name: 'eğlence2',
  description: 'Tüm komutları gösterir.',
  usage: 'yardım [komut]'
};
