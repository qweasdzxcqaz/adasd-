const Discord = require('discord.js');
const loglar = require('../ayarlar.json')

var prefix = loglar.prefix;

exports.run = async (client, message, params, args) => {

	const yardım = new  Discord.RichEmbed()
	.setColor()
	.setAuthor(`Sruqzy`, client.user.avatarURL)
	.setThumbnail(client.user.avatarURL)
	.addField(`Yardım Menüsü`, `**+eğlence** = Eğlence Komutları + kullanıcı komutları \n   **+eğlence2** = eğlence + kullanıcı komutları (2)\n**+yetkili** = Yetkili Komutları\n**+yetkili2** = yetkili komutları2`)
    .setFooter(`${message.author.username} Tarafından İstendi.`, message.author.avatarURL)

    return message.channel.sendEmbed(yardım);

};



exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['yardım', 'help'],
  permLevel: 0
};

exports.help = {
  name: 'm',
  description: 'Belirlenen miktarda mesajı siler.',
  usage: 'yardım '
};
