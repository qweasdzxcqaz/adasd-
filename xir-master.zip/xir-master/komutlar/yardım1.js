const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

exports.run = (client, message, params) => {
  const embedyardim = new Discord.RichEmbed()
  .setTitle("Komutlar")
  .setDescription('')
  .setColor(0x00ffff)
  .addField("**Eğlence Komutları + kullanıcı komutları (1)**", "+ayarlar ayarları gösterir \n+yazıtura yazı tura!\n+şifre rastgele şifre verir\n+8ball (soru)\n+hesapla (işlem)\n+woodie dene ve gör\n +mca dene ve gör!\n +1vs1 1vs1 atarsınız! \n +wasted wasted!\n+youtube youtube\n +spotify kimin hangi şarkıyı dinledigini söyler\n+banned = Dene ve Gör!,+afk = afk olursunuz! \n+ailemiz bizi kullanan sunucuları gösteririr \n+ascii kodlama yapanlara özel kodlama isim üretici (ascii)\n+atatürk atamızı gösterir \n+atatürk-çerçeve profilinize ataamızı ekler\n+bayrak şanlı bayrağımızı gösterir\n+bravery profilinize bravery ekler\n+canlıdestek canlı destek alırsınız \n+davet davet komutları \n+geldim afk iken geldiyseniz bu komutu yazmanız yeterli\n+hız bütün internet istatistiklerinizi gösterir\n+olay dene ve gör \n+öp isim dene ve gör\n+sigara sigara içersiniz ")
  .setFooter('**--------------------------**')
  if (!params[0]) {
    const commandNames = Array.from(client.commands.keys());
    const longest = commandNames.reduce((long, str) => Math.max(long, str.length), 0);
    message.channel.send(embedyardim);
  } else {
    let command = params[0];
    if (client.commands.has(command)) {
      command = client.commands.get(command);
      message.author.send('asciidoc', `= ${command.help.name} = \n${command.help.description}\nDoğru kullanım: ` + prefix + `${command.help.usage}`);
    }
  }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['eğlence'],
  permLevel: 0
};

exports.help = {
  name: 'eğlewwwwnce',
  description: 'Tüm komutları gösterir.',
  usage: 'yardım [komut]'
};
